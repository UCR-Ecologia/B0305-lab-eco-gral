# Cómo usar la plantilla B305 en Quarto

1. Coloque estos archivos en la misma carpeta:
   - B305-report-template.qmd
   - reference.docx
   - references.bib
   - apa.csl
   - styles.css

2. Abra el QMD en RStudio o VS Code y use **Render**.

3. Cite con `[@begon2006ecology]` para (Begon et al., 2006).
